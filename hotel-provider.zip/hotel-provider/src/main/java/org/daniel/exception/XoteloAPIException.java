package org.daniel.exception;

import java.io.IOException;

public class XoteloAPIException extends IOException {
	public XoteloAPIException(String message, Throwable cause) {
		super(message, cause);
	}
}
