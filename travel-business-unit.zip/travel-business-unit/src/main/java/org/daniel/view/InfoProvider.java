package org.daniel.view;

public class InfoProvider {
}
